import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";

export default function VerifyEmailGate() {
  const { user, signOut, resendVerification } = useAuth();
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);

  const handleResend = async () => {
    setSending(true);
    setError(null);
    const { error } = await resendVerification(user.email);
    if (error) setError(error.message);
    else setSent(true);
    setSending(false);
  };

  return (
    <div style={styles.wrap}>
      <div style={styles.card}>
        <span style={styles.crown}>♛</span>
        <h1 style={styles.title}>Verify your email</h1>
        <p style={styles.body}>
          We sent a verification link to <strong>{user?.email}</strong>. Please confirm your
          address before playing — this keeps accounts and points secure.
        </p>
        {sent && <div style={styles.success}>Verification email resent.</div>}
        {error && <div style={styles.error}>{error}</div>}
        <button style={styles.btnPrimary} onClick={handleResend} disabled={sending}>
          {sending ? "Sending…" : "Resend verification email"}
        </button>
        <button style={styles.linkBtn} onClick={signOut}>Sign out</button>
      </div>
    </div>
  );
}

const styles = {
  wrap: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "radial-gradient(ellipse at top, #4a1f73 0%, #2d1150 38%, #1a0a30 70%, #100620 100%)",
    fontFamily: "'JetBrains Mono', monospace",
    color: "#F2ECDB",
    padding: 20,
    boxSizing: "border-box",
  },
  card: {
    width: "100%",
    maxWidth: 380,
    background: "rgba(0,0,0,0.3)",
    border: "1px solid rgba(201,168,106,0.35)",
    borderRadius: 14,
    padding: "32px 28px",
    display: "flex",
    flexDirection: "column",
    gap: 14,
    textAlign: "center",
    boxShadow: "0 20px 60px rgba(0,0,0,0.5)",
  },
  crown: { fontSize: 28, color: "#D4AF37" },
  title: { fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 22, margin: "4px 0 0" },
  body: { fontSize: 13, opacity: 0.85, lineHeight: 1.6 },
  btnPrimary: {
    marginTop: 6,
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 13,
    padding: "12px 16px",
    borderRadius: 8,
    border: "1px solid #9a7a1f",
    background: "linear-gradient(180deg, #D4AF37, #b8932a)",
    color: "#1B2A22",
    fontWeight: 700,
    cursor: "pointer",
  },
  linkBtn: {
    background: "none",
    border: "none",
    color: "#D4AF37",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: "'JetBrains Mono', monospace",
    textDecoration: "underline",
    opacity: 0.85,
  },
  success: {
    fontSize: 11,
    color: "#7FBF7F",
    background: "rgba(127,191,127,0.1)",
    border: "1px solid rgba(127,191,127,0.4)",
    borderRadius: 6,
    padding: "8px 10px",
  },
  error: {
    fontSize: 11,
    color: "#E25555",
    background: "rgba(226,85,85,0.1)",
    border: "1px solid rgba(226,85,85,0.4)",
    borderRadius: 6,
    padding: "8px 10px",
  },
};

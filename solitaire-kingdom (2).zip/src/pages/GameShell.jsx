import { useState, useCallback, useEffect, useRef } from "react";
import { useAuth } from "../contexts/AuthContext";
import KlondikeGame from "../components/KlondikeGame";
import {
  fetchDailyTaskDefs,
  fetchTodayTaskProgress,
  incrementTaskProgress,
  claimTaskReward,
  logGameSession,
  adjustPoints,
  addPlaySeconds,
} from "../lib/gameData";

const TIERS_POINTS = [
  { id: "pts-30", label: "30 Point Table", entry: 30 },
  { id: "pts-850", label: "850 Point Table", entry: 850 },
];

function isFriday(d = new Date()) { return d.getDay() === 5; }

function FlyingArrow({ id, onDone }) {
  useEffect(() => {
    const t = setTimeout(() => onDone(id), 900);
    return () => clearTimeout(t);
  }, [id, onDone]);
  return (
    <svg className="sk-arrow" width="46" height="46" viewBox="0 0 46 46" style={{ position: "fixed", pointerEvents: "none", zIndex: 200 }}>
      <polygon points="23,2 34,24 26,24 26,44 20,44 20,24 12,24" fill="#D4AF37" stroke="#9a7a1f" strokeWidth="1" />
    </svg>
  );
}

export default function GameShell() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const [screen, setScreen] = useState("lobby"); // lobby | game | tasks
  const [drawThree, setDrawThree] = useState(false);
  const [toast, setToast] = useState(null);
  const [activeTier, setActiveTier] = useState(null);
  const [taskDefs, setTaskDefs] = useState([]);
  const [taskProgress, setTaskProgress] = useState([]); // rows from task_progress, joined with defs
  const [arrows, setArrows] = useState([]);
  const [loadingTasks, setLoadingTasks] = useState(true);
  const friday = isFriday();

  const points = profile?.points ?? 0;
  const playSecondsTotalRef = useRef(profile?.total_play_seconds ?? 0);
  const sessionSecondsRef = useRef(0);
  const flushIntervalRef = useRef(null);

  useEffect(() => {
    playSecondsTotalRef.current = profile?.total_play_seconds ?? 0;
  }, [profile?.total_play_seconds]);

  const fireToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2400);
  }, []);

  const fireArrows = useCallback((count = 1) => {
    setArrows((prev) => {
      const next = [...prev];
      for (let i = 0; i < count; i++) {
        const id = `${Date.now()}-${i}-${Math.random()}`;
        const startX = window.innerWidth ? window.innerWidth - 80 - Math.random() * 60 : 300;
        const startY = window.innerHeight ? window.innerHeight - 120 : 400;
        next.push({ id, startX, startY });
      }
      return next;
    });
  }, []);
  const removeArrow = useCallback((id) => {
    setArrows((prev) => prev.filter((a) => a.id !== id));
  }, []);

  // Load task defs + today's progress on mount / user change
  const loadTasks = useCallback(async () => {
    if (!user) return;
    setLoadingTasks(true);
    try {
      const [defs, progress] = await Promise.all([
        fetchDailyTaskDefs(),
        fetchTodayTaskProgress(user.id),
      ]);
      setTaskDefs(defs);
      setTaskProgress(progress);
    } catch (err) {
      console.error("Failed to load tasks:", err.message);
      fireToast("Couldn't load daily tasks — check your connection.");
    } finally {
      setLoadingTasks(false);
    }
  }, [user, fireToast]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  // Periodically flush accumulated play seconds to the database (every 30s),
  // plus on unmount, so total_play_seconds stays roughly current without
  // hammering the DB on every tick.
  useEffect(() => {
    const tick = setInterval(() => {
      sessionSecondsRef.current += 1;
    }, 1000);

    flushIntervalRef.current = setInterval(async () => {
      const delta = sessionSecondsRef.current;
      if (delta <= 0 || !user) return;
      sessionSecondsRef.current = 0;
      try {
        const updated = await addPlaySeconds(user.id, playSecondsTotalRef.current, delta);
        playSecondsTotalRef.current = updated.total_play_seconds;
        refreshProfile();
      } catch (err) {
        console.error("Failed to flush play time:", err.message);
        sessionSecondsRef.current += delta; // retry next tick
      }
    }, 30000);

    return () => {
      clearInterval(tick);
      clearInterval(flushIntervalRef.current);
    };
  }, [user, refreshProfile]);

  // Merge defs + progress into a display-friendly list
  const tasksDisplay = taskDefs.map((def) => {
    const row = taskProgress.find((p) => p.task_id === def.id);
    return {
      def,
      row,
      progress: row?.progress ?? 0,
      claimed: row?.claimed ?? false,
    };
  });

  const handleMove = useCallback(async () => {
    if (!user) return;
    try {
      const updated = await incrementTaskProgress(user.id, "moves", taskDefs, 1);
      if (updated.length > 0) {
        setTaskProgress((prev) => {
          const map = new Map(prev.map((p) => [p.task_id, p]));
          updated.forEach((u) => map.set(u.task_id, u));
          return Array.from(map.values());
        });
        const justCompleted = updated.find((u) => u.progress >= u.target);
        if (justCompleted) {
          fireArrows(1);
          fireToast("Daily task complete! Claim your reward in Tasks.");
        }
      }
    } catch (err) {
      console.error("Failed to record move:", err.message);
    }
  }, [user, taskDefs, fireArrows, fireToast]);

  const handleWin = useCallback(async (moves) => {
    if (!user) return;
    try {
      const [winUpdates, playUpdates] = await Promise.all([
        incrementTaskProgress(user.id, "win", taskDefs, 1),
        incrementTaskProgress(user.id, "play", taskDefs, 1),
      ]);
      const allUpdates = [...winUpdates, ...playUpdates];
      if (allUpdates.length > 0) {
        setTaskProgress((prev) => {
          const map = new Map(prev.map((p) => [p.task_id, p]));
          allUpdates.forEach((u) => map.set(u.task_id, u));
          return Array.from(map.values());
        });
        if (allUpdates.some((u) => u.progress >= u.target)) {
          fireArrows(1);
          fireToast("Daily task complete! Claim your reward in Tasks.");
        }
      }

      // Participation + win bonus, same formula as original design.
      const participation = 15;
      const winBonus = activeTier ? Math.round(activeTier.entry * 0.5) : 25;
      const earned = participation + winBonus;
      await adjustPoints(user.id, points, earned);
      await refreshProfile();

      await logGameSession(user.id, {
        tierId: activeTier?.id ?? "practice",
        won: true,
        moves,
        pointsEarned: earned,
        isTournament: friday,
      });

      fireToast(`Hand won! +${participation} participation, +${winBonus} win bonus.`);
    } catch (err) {
      console.error("Failed to record win:", err.message);
      fireToast("Win recorded locally, but saving to your account failed.");
    }
  }, [user, taskDefs, activeTier, points, friday, fireArrows, fireToast, refreshProfile]);

  const claimTask = useCallback(async (taskDisplay) => {
    if (!user || !taskDisplay.row || taskDisplay.claimed || taskDisplay.progress < taskDisplay.def.target) return;
    try {
      const { claimedRow } = await claimTaskReward(
        user.id,
        taskDisplay.row,
        taskDisplay.def.reward_points,
        points
      );
      setTaskProgress((prev) => prev.map((p) => (p.id === claimedRow.id ? claimedRow : p)));
      await refreshProfile();
      fireToast(`+${taskDisplay.def.reward_points} points claimed: ${taskDisplay.def.label}`);
    } catch (err) {
      console.error("Failed to claim task:", err.message);
      fireToast("Couldn't claim reward — try again.");
    }
  }, [user, points, refreshProfile, fireToast]);

  const enterTable = useCallback(async (tier) => {
    if (points < tier.entry) {
      fireToast(`Not enough points — you need ${tier.entry}, you have ${points}.`);
      return;
    }
    try {
      await adjustPoints(user.id, points, -tier.entry);
      await refreshProfile();
      setActiveTier(tier);
      setScreen("game");
      fireToast(`Joined ${tier.label}. Good luck!`);
    } catch (err) {
      console.error("Failed to join table:", err.message);
      fireToast("Couldn't join table — try again.");
    }
  }, [points, user, refreshProfile, fireToast]);

  return (
    <div style={shellStyles.root}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=JetBrains+Mono:wght@400;600&display=swap');
        .sk-card { transition: transform 0.12s ease, filter 0.12s ease; cursor: pointer; }
        .sk-card:hover { filter: brightness(1.06); }
        .sk-card.sk-selected { transform: translateY(-8px); filter: drop-shadow(0 6px 10px rgba(0,0,0,0.45)) brightness(1.08); }
        .sk-card.sk-hinted { animation: sk-pulse 0.9s ease-in-out infinite; }
        @keyframes sk-pulse { 0%,100% { filter: drop-shadow(0 0 0 rgba(201,168,106,0)); } 50% { filter: drop-shadow(0 0 14px rgba(201,168,106,0.85)); } }
        .sk-arrow { animation: sk-fly 0.9s cubic-bezier(.2,.8,.3,1) forwards; }
        @keyframes sk-fly {
          0% { transform: translate(0,0) scale(0.6) rotate(0deg); opacity: 0; }
          15% { opacity: 1; }
          100% { transform: translate(-220px, -340px) scale(1.15) rotate(-18deg); opacity: 0; }
        }
        button:focus-visible, .sk-card:focus-visible { outline: 2px solid #D4AF37; outline-offset: 2px; }
        @media (prefers-reduced-motion: reduce) {
          .sk-card, .sk-card.sk-selected, .sk-card.sk-hinted, .sk-arrow { transition: none; animation: none; }
        }
      `}</style>

      <div style={shellStyles.vignette} />

      {arrows.map((a) => (
        <div key={a.id} style={{ position: "fixed", left: a.startX, top: a.startY, zIndex: 200 }}>
          <FlyingArrow id={a.id} onDone={removeArrow} />
        </div>
      ))}

      <header style={shellStyles.header}>
        <div style={shellStyles.brandRow} onClick={() => setScreen("lobby")} role="button" tabIndex={0}>
          <span style={shellStyles.crown}>♛</span>
          <h1 style={shellStyles.title}>Solitaire Kingdom</h1>
        </div>
        <div style={shellStyles.headerRight}>
          {friday && <span style={shellStyles.fridayBadge}>★ Tournament Friday</span>}
          <div style={shellStyles.pointsPill}>
            <span style={shellStyles.pointsLabel}>Points</span>
            <span style={shellStyles.pointsValue}>{points.toLocaleString()}</span>
          </div>
          <button style={shellStyles.navBtn} onClick={() => setScreen("tasks")}>Tasks</button>
          {screen !== "lobby" && <button style={shellStyles.navBtn} onClick={() => setScreen("lobby")}>Lobby</button>}
          <button style={shellStyles.navBtn} onClick={signOut}>Sign out</button>
        </div>
      </header>

      {screen === "lobby" && (
        <main style={shellStyles.lobby}>
          <p style={shellStyles.lobbySub}>
            Welcome, {profile?.display_name || "Player"}. Choose a table to play a hand.
          </p>

          <h2 style={shellStyles.sectionTitle}>Points tables</h2>
          <div style={shellStyles.tierGrid}>
            {TIERS_POINTS.map((t) => (
              <button key={t.id} style={shellStyles.tierCard} onClick={() => enterTable(t)}>
                <span style={shellStyles.tierEntry}>{t.entry.toLocaleString()} pts</span>
                <span style={shellStyles.tierLabel}>{t.label}</span>
                <span style={shellStyles.tierCta}>Play now →</span>
              </button>
            ))}
          </div>

          <div style={shellStyles.infoCard}>
            Every hand you play earns participation points, win or lose. Tournament play is featured every Friday.
          </div>
        </main>
      )}

      {screen === "game" && (
        <main>
          <div style={shellStyles.gameContextBar}>
            Playing: {activeTier ? activeTier.label : "Practice"} {friday && <span style={shellStyles.fridayBadgeSmall}>Tournament Day</span>}
          </div>
          <KlondikeGame
            onWin={handleWin}
            onMove={handleMove}
            drawThree={drawThree}
            setDrawThree={setDrawThree}
            isTournament={friday}
            onTimeUp={() => fireToast("Time's up for this tournament hand — dealing a fresh one.")}
          />
        </main>
      )}

      {screen === "tasks" && (
        <main style={shellStyles.lobby}>
          <h2 style={shellStyles.sectionTitle}>Daily tasks</h2>
          {loadingTasks ? (
            <p style={{ opacity: 0.7, fontSize: 12 }}>Loading tasks…</p>
          ) : (
            <div style={shellStyles.taskList}>
              {tasksDisplay.map((t) => {
                const complete = t.progress >= t.def.target;
                return (
                  <div key={t.def.id} style={shellStyles.taskRow}>
                    <div style={shellStyles.taskInfo}>
                      <span style={shellStyles.taskLabel}>{t.def.label}</span>
                      <div style={shellStyles.progressTrack}>
                        <div style={{ ...shellStyles.progressFill, width: `${Math.min(100, (t.progress / t.def.target) * 100)}%` }} />
                      </div>
                      <span style={shellStyles.taskProgressText}>{t.progress} / {t.def.target}</span>
                    </div>
                    <button
                      style={{ ...shellStyles.navBtn, ...(complete && !t.claimed ? shellStyles.btnPrimary : {}), opacity: t.claimed ? 0.5 : 1 }}
                      disabled={!complete || t.claimed}
                      onClick={() => claimTask(t)}
                    >
                      {t.claimed ? "Claimed" : `Claim +${t.def.reward_points}`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
          <div style={shellStyles.infoCard}>
            Tasks reset daily. Completing one sends a flying arrow your way and adds points to your balance.
          </div>
        </main>
      )}

      {toast && <div style={shellStyles.toast}>{toast}</div>}
    </div>
  );
}

/* ---------------- styles ---------------- */
const shellStyles = {
  root: { position: "relative", minHeight: "100%", width: "100%", background: "radial-gradient(ellipse at top, #4a1f73 0%, #2d1150 38%, #1a0a30 70%, #100620 100%)", fontFamily: "'JetBrains Mono', monospace", color: "#F2ECDB", boxSizing: "border-box", overflowX: "hidden" },
  vignette: { position: "absolute", inset: 0, pointerEvents: "none", boxShadow: "inset 0 0 140px rgba(0,0,0,0.6)", backgroundImage: "radial-gradient(circle at 50% 0%, rgba(212,175,55,0.07), transparent 55%)" },
  header: { display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, padding: "16px 20px", borderBottom: "1px solid rgba(201,168,106,0.25)" },
  brandRow: { display: "flex", alignItems: "center", gap: 8, cursor: "pointer" },
  crown: { fontSize: 22, color: "#D4AF37" },
  title: { fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 22, letterSpacing: 0.5, margin: 0 },
  headerRight: { display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" },
  fridayBadge: { fontSize: 11, color: "#D4AF37", border: "1px solid rgba(201,168,106,0.5)", borderRadius: 20, padding: "5px 10px", letterSpacing: 0.5 },
  fridayBadgeSmall: { fontSize: 10, color: "#D4AF37", border: "1px solid rgba(201,168,106,0.5)", borderRadius: 20, padding: "3px 8px", marginLeft: 8 },
  pointsPill: { display: "flex", alignItems: "center", gap: 6, background: "rgba(0,0,0,0.3)", border: "1px solid rgba(201,168,106,0.35)", borderRadius: 20, padding: "6px 12px" },
  pointsLabel: { fontSize: 9, opacity: 0.6, letterSpacing: 1, textTransform: "uppercase" },
  pointsValue: { fontSize: 14, fontWeight: 700, color: "#D4AF37" },
  navBtn: { fontFamily: "'JetBrains Mono', monospace", fontSize: 11, padding: "8px 14px", borderRadius: 6, border: "1px solid rgba(201,168,106,0.45)", background: "rgba(0,0,0,0.25)", color: "#F2ECDB", cursor: "pointer" },
  btnPrimary: { background: "linear-gradient(180deg, #D4AF37, #b8932a)", color: "#1B2A22", fontWeight: 700, border: "1px solid #9a7a1f" },
  lobby: { maxWidth: 760, margin: "0 auto", padding: "24px 20px 60px" },
  lobbySub: { opacity: 0.75, fontSize: 13, marginBottom: 22 },
  sectionTitle: { fontFamily: "'Playfair Display', serif", fontSize: 18, marginBottom: 12, marginTop: 28 },
  tierGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 12 },
  tierCard: { display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 4, background: "rgba(0,0,0,0.25)", border: "1px solid rgba(201,168,106,0.35)", borderRadius: 10, padding: "16px 16px", cursor: "pointer", textAlign: "left", color: "#F2ECDB", fontFamily: "'JetBrains Mono', monospace" },
  tierEntry: { fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#D4AF37", fontWeight: 700 },
  tierLabel: { fontSize: 12, opacity: 0.85 },
  tierCta: { fontSize: 11, color: "#D4AF37", marginTop: 6 },
  infoCard: { marginTop: 28, background: "rgba(0,0,0,0.2)", border: "1px solid rgba(201,168,106,0.25)", borderRadius: 10, padding: "14px 16px", fontSize: 12, opacity: 0.85, lineHeight: 1.6 },
  gameContextBar: { textAlign: "center", fontSize: 12, opacity: 0.8, padding: "12px 0 18px" },
  taskList: { display: "flex", flexDirection: "column", gap: 10 },
  taskRow: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14, background: "rgba(0,0,0,0.25)", border: "1px solid rgba(201,168,106,0.3)", borderRadius: 10, padding: "14px 16px" },
  taskInfo: { display: "flex", flexDirection: "column", gap: 6, flex: 1 },
  taskLabel: { fontSize: 13 },
  progressTrack: { height: 6, borderRadius: 3, background: "rgba(255,255,255,0.08)", overflow: "hidden" },
  progressFill: { height: "100%", background: "linear-gradient(90deg, #D4AF37, #b8932a)" },
  taskProgressText: { fontSize: 10, opacity: 0.6 },
  toast: { position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", background: "rgba(0,0,0,0.75)", border: "1px solid rgba(201,168,106,0.4)", padding: "10px 18px", borderRadius: 8, fontSize: 12, zIndex: 150 },
};

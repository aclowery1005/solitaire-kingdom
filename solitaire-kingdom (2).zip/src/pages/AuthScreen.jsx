import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";

export default function AuthScreen() {
  const { signUp, signIn } = useAuth();
  const [mode, setMode] = useState("signin"); // 'signin' | 'signup'
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [verifyPending, setVerifyPending] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (mode === "signup") {
        const { data, error } = await signUp(email, password, displayName);
        if (error) {
          setError(error.message);
        } else if (data?.user && !data?.session) {
          // Email confirmation required — no session yet.
          setVerifyPending(true);
        }
      } else {
        const { error } = await signIn(email, password);
        if (error) setError(error.message);
      }
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  };

  if (verifyPending) {
    return (
      <div style={styles.wrap}>
        <div style={styles.card}>
          <span style={styles.crown}>♛</span>
          <h1 style={styles.title}>Check your email</h1>
          <p style={styles.body}>
            We sent a verification link to <strong>{email}</strong>. Click it to activate your
            account, then come back here and sign in.
          </p>
          <button style={styles.btnPrimary} onClick={() => { setVerifyPending(false); setMode("signin"); }}>
            Back to sign in
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.wrap}>
      <form style={styles.card} onSubmit={handleSubmit}>
        <span style={styles.crown}>♛</span>
        <h1 style={styles.title}>Solitaire Kingdom</h1>
        <p style={styles.sub}>{mode === "signin" ? "Welcome back." : "Create your account."}</p>

        {mode === "signup" && (
          <label style={styles.label}>
            Display name
            <input
              style={styles.input}
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Player"
              maxLength={32}
            />
          </label>
        )}

        <label style={styles.label}>
          Email
          <input
            style={styles.input}
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
          />
        </label>

        <label style={styles.label}>
          Password
          <input
            style={styles.input}
            type="password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="At least 6 characters"
            autoComplete={mode === "signin" ? "current-password" : "new-password"}
          />
        </label>

        {error && <div style={styles.error}>{error}</div>}

        <button style={styles.btnPrimary} type="submit" disabled={submitting}>
          {submitting ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
        </button>

        <button
          type="button"
          style={styles.linkBtn}
          onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(null); }}
        >
          {mode === "signin" ? "Need an account? Sign up" : "Already have an account? Sign in"}
        </button>
      </form>
    </div>
  );
}

const styles = {
  wrap: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "radial-gradient(ellipse at top, #4a1f73 0%, #2d1150 38%, #1a0a30 70%, #100620 100%)",
    fontFamily: "'JetBrains Mono', monospace",
    color: "#F2ECDB",
    padding: 20,
    boxSizing: "border-box",
  },
  card: {
    width: "100%",
    maxWidth: 380,
    background: "rgba(0,0,0,0.3)",
    border: "1px solid rgba(201,168,106,0.35)",
    borderRadius: 14,
    padding: "32px 28px",
    display: "flex",
    flexDirection: "column",
    gap: 14,
    textAlign: "center",
    boxShadow: "0 20px 60px rgba(0,0,0,0.5)",
  },
  crown: { fontSize: 28, color: "#D4AF37" },
  title: { fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 22, margin: "4px 0 0" },
  sub: { fontSize: 12, opacity: 0.75, margin: 0 },
  body: { fontSize: 13, opacity: 0.85, lineHeight: 1.6 },
  label: { display: "flex", flexDirection: "column", gap: 6, fontSize: 11, textAlign: "left", letterSpacing: 0.5, opacity: 0.85 },
  input: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 13,
    padding: "10px 12px",
    borderRadius: 8,
    border: "1px solid rgba(201,168,106,0.4)",
    background: "rgba(255,255,255,0.04)",
    color: "#F2ECDB",
    outline: "none",
  },
  btnPrimary: {
    marginTop: 6,
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 13,
    padding: "12px 16px",
    borderRadius: 8,
    border: "1px solid #9a7a1f",
    background: "linear-gradient(180deg, #D4AF37, #b8932a)",
    color: "#1B2A22",
    fontWeight: 700,
    cursor: "pointer",
  },
  linkBtn: {
    background: "none",
    border: "none",
    color: "#D4AF37",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: "'JetBrains Mono', monospace",
    textDecoration: "underline",
    opacity: 0.85,
  },
  error: {
    fontSize: 11,
    color: "#E25555",
    background: "rgba(226,85,85,0.1)",
    border: "1px solid rgba(226,85,85,0.4)",
    borderRadius: 6,
    padding: "8px 10px",
  },
};
